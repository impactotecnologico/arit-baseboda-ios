//
//  BaseSearchController.h
//  CraftARCommons
//
//  Created by Luis Martinell Andreu on 12/11/15.
//  Copyright © 2015 Luis Martinell Andreu. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CraftARProtocols.h"

@interface BaseSearchController : NSObject <CameraSearchController>

@end
